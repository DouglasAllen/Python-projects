absdga
======

Brief Description
-----------------

This is a introductory level project that teaches RubyLearning's 
"An Introduction to Python" course students on how to uplaod their modules to Python Package Index.

Usage
-----

import absdga

print(absdga.absdga(-20))

or

from absdga import *

print(absdga(-20))


