""" A function that returns the
absolute value of a number"""
def absdga(x):
  if x < 0:
    return -x
  elif x > 0:
    return x