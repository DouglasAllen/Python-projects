#include <CoreMIDI/CoreMIDI.h>

void main()
{
    printf("%d\n", MIDIGetNumberOfDevices());
}

